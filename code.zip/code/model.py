import torch as t
from torch import nn
import torch
from layers import HGNN_conv
import torch.nn.functional as F
from torch_geometric.nn import GATConv
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
from bipartite_gat import BipartiteGAT
from bipartite_gat import BipartiteGAT1
def SparseTensor(row, col, value, sparse_sizes):
    return torch.sparse_coo_tensor(indices=torch.stack([row, col]),
                                   values=value,
                                  size=sparse_sizes)
def load_GCN_inter(adj_t):
    deg = adj_t.sum(dim=1)
    deg_inv_sqrt = deg.pow(-0.5)
    deg_inv_sqrt.masked_fill_(torch.isinf(deg_inv_sqrt), 0.)
    adj_t.mul_(deg_inv_sqrt.view(-1, 1))
    adj_t.mul_(deg_inv_sqrt.view(1, -1))
    return adj_t
class EdgeDropout(nn.Module):
    def __init__(self, keep_prob=0.5):
        super(EdgeDropout, self).__init__()
        assert keep_prob>0
        self.keep_prob = keep_prob
        self.register_buffer("p", torch.tensor(keep_prob))
    def forward(self, edge_index, edge_weight):
        if self.training:
            mask = torch.rand(edge_index.shape[1], device=edge_weight.device)
            mask = torch.floor(mask+self.p).type(torch.bool)
            edge_index = edge_index[:, mask]
            edge_weight = edge_weight[mask]/self.p
        return edge_index, edge_weight
class ECAAttention(nn.Module):
    def __init__(self, kernel_size=3):
        super().__init__()
        self.gap=nn.AdaptiveAvgPool2d(1)
        self.conv=nn.Conv1d(1,1,kernel_size=kernel_size,padding=(kernel_size-1)//2)
        self.sigmoid=nn.Sigmoid()
    def forward(self, x):
        y=self.gap(x)
        y=y.squeeze(-1).permute(0,2,1)
        y=self.conv(y)
        y=self.sigmoid(y)
        y=y.permute(0,2,1).unsqueeze(-1)
        return x*y.expand_as(x)
class Model(nn.Module):
    def __init__(self, sizes):
        super(Model, self).__init__()
        self.fg = sizes.fg
        self.fd = sizes.fd
        self.m = sizes.m
        self.d = sizes.d
        self._dty_nets = sizes.btypes
        self.channel = len(sizes.btypes)
        self.p = sizes.p
        self.psa = ECAAttention(kernel_size=3)
        self.psa1 = ECAAttention(kernel_size=3)
        self.HyperConv_r1 = dict()
        self.HyperConv_r2 = dict()
        for dty in self._dty_nets:
            self.HyperConv_r1[dty] = HGNN_conv(self.m, 128)
        for dty in self._dty_nets:
            self.HyperConv_r2[dty] = HGNN_conv(128, 128)
        self.edge_dropout = EdgeDropout(keep_prob=1 - sizes.drop)
        self.act=nn.Sigmoid()
        self.protein_feature_num = 256
        self.p1=0.2
        self.drug_protein = BipartiteGAT(self.m, self.protein_feature_num, 256, heads=1, dropout=self.p1,
                                         flow='source_to_target', attention_concat=False, multi_head_concat=False)
        self.disease_protein = BipartiteGAT(self.d, self.protein_feature_num,256, heads=1, dropout=self.p1,
                                            flow='source_to_target', attention_concat=False, multi_head_concat=False)
        self.head=1
        self.ppi_GAT = GATConv(2 * 256,128, heads=self.head, dropout=self.p1, concat=True)
        self.protein_drug1 = BipartiteGAT1(128,self.head*128,128, heads=1, dropout=0.1,
                                         flow='target_to_source', attention_concat=False, multi_head_concat=False)
        self.protein_disease1 = BipartiteGAT1(128,self.head*128,128, heads=1, dropout=0.1,
                                            flow='target_to_source', attention_concat=False, multi_head_concat=False)
        self.pp=0.4
        self.dropout_h = nn.Dropout(self.pp)
        self.dropout =nn.Dropout(self.pp)
        self.dropout_intrar1 = nn.Dropout(self.pp)
        self.dropout_intrad1 =nn.Dropout(self.pp)
        self.dropout_inter2 = nn.Dropout(self.pp)
        self.dropout_intrar2 = nn.Dropout(self.pp)
        self.dropout_intrad2 = nn.Dropout(self.pp)
        dropout=0.4
        self.dropout = nn.Dropout(dropout)
        self.HGNN= HGNN_conv(self.d+self.m, 128,bias =True)
        self.HGNN_inter2 = HGNN_conv(128, 128, bias=True)
        self.HGNN1 = HGNN_conv(self.m, 128, bias=True)
        self.HGNN2 = HGNN_conv(self.d , 128, bias=True)
        self.HGNN22 = HGNN_conv(128 , 128, bias=True)
        self.weight = nn.Parameter(torch.Tensor(self.m+self.d,self.m+self.d))
        self.weight2 = nn.Parameter(torch.Tensor(self.m+self.d, 128))
        self.reset_parameters()
    def reset_parameters(self):
        nn.init.xavier_uniform_(self.weight)
        nn.init.xavier_uniform_(self.weight2)
        self._cached_edge_index = None
        self._cached_adj_t = None
    def forward(self,dd_matrix,mm_matrix,GR,GD,zero,ur_edge_index, ur_edge_weight,vr_edge_index, vr_edge_weight,r_p_one,d_p_one,p_p,hygraphs):
        ur_edge_index, ur_edge_weight = self.edge_dropout(ur_edge_index, ur_edge_weight)
        vr_edge_index, vr_edge_weight = self.edge_dropout(vr_edge_index, vr_edge_weight)
        edge_index1 = SparseTensor(row=ur_edge_index[0], col=ur_edge_index[1],
                                  value= ur_edge_weight,
                                  sparse_sizes=(self.m+self.d, self.m+self.d))
        edge_index1=edge_index1.to_dense()
        edge_index2 = SparseTensor(row=vr_edge_index[0], col=vr_edge_index[1],
                                  value= vr_edge_weight,
                                  sparse_sizes=(self.m+self.d, self.m+self.d))
        edge_index2 = edge_index2.to_dense()
        edge_index3=edge_index2+edge_index1
        r1 = t.FloatTensor(mm_matrix).cuda()
        d1 = t.FloatTensor(dd_matrix).cuda()
        G_inter = load_GCN_inter(edge_index3)
        ii=t.mul(zero, t.matmul(self.dropout_h(edge_index3), self.weight))
        inter_feature = self.HGNN(self.dropout(ii), G_inter)
        GD = t.FloatTensor(GD).cuda()
        add_xr = dict()
        a = []
        for dty in self._dty_nets:
            add_xr[dty] = self.HyperConv_r1[dty](self.dropout_intrar1(r1), hygraphs[dty])
            a.append(add_xr[dty])
        all_xr = torch.cat(a, 1)
        all_xr = all_xr.view(1, self.channel, 128, -1)
        xc = self.psa(all_xr)
        xc = xc.squeeze()
        xc = xc.sum(dim=0).T
        ###########################
        intra_feature2 = self.HGNN2(self.dropout_intrad1(d1), GD)
        intra_feature=torch.cat((xc,intra_feature2),dim=0)
        r_p_one=r_p_one.cuda()
        d_p_one=d_p_one.cuda()
        p_p=p_p.cuda()
        r_p_one=reversed(r_p_one)
        d_p_one = reversed(d_p_one)
        x_d = t.zeros(self.d, 128).cuda()
        x_r = t.zeros(self.m, 128).cuda()
        protein_feature = torch.zeros(self.p, self.fd).float().to(device)
        protein_feature_from_drug = self.drug_protein((t.FloatTensor(mm_matrix).cuda(), protein_feature),
                                                      r_p_one,
                                                      size=[self.m, self.p])
        protein_feature_from_disease = self.disease_protein((t.FloatTensor(dd_matrix).cuda(), protein_feature),
                                                            d_p_one,
                                                            size=[self.d, self.p])
        protein_feature = torch.cat([protein_feature_from_drug, protein_feature_from_disease], dim=1)
        protein_feature = F.relu(self.ppi_GAT(protein_feature, p_p))
        drug_feature =F.relu( self.protein_drug1((x_r, protein_feature), r_p_one, size=[self.m, self.p]))
        disease_feature = F.relu(self.protein_disease1((x_d.cuda(), protein_feature), d_p_one, size=[self.d, self.p]))
        inter_feature_protein = torch.cat((drug_feature, disease_feature), dim=0)
        ##################################
        z = F.relu(intra_feature)+F.relu(inter_feature)\
            +inter_feature_protein
        ii2=t.mul(z, t.matmul(self.dropout_h(edge_index3), self.weight2))
        inter_feature = self.HGNN_inter2(self.dropout_inter2(ii2), G_inter)
        #################### attention2
        add_xr2 = dict()
        a1 = []
        for dty in self._dty_nets:
            add_xr2[dty] = self.HyperConv_r2[dty](self.dropout_intrar2(z[:self.m, :]), hygraphs[dty])
            a1.append(add_xr2[dty])
        all_xr = torch.cat(a1, 1)
        all_xr = all_xr.view(1, self.channel, 128, -1)
        xc2 = self.psa1(all_xr)
        xc2 = xc2.squeeze()
        xc2 = xc2.sum(dim=0).T
        intra_feature2 = self.HGNN22(self.dropout_intrad2(z[self.m:, :]), GD)
        intra_feature = torch.cat((xc2, intra_feature2), dim=0)
        y = intra_feature + inter_feature
        out1=z+y
        out1=self.dropout(out1)
        R = out1[:self.m]
        D = out1[self.m:]
        out2 = R@D.T
        score= self.act(out2)
        return score