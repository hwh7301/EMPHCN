from torch import nn, optim
import hypergraph_utils  as hgut
from model import Model
import metric_fn
import numpy as  np
import torch
import scipy.io as scio
import os
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
import torch.nn.functional as F
import argparse
def parse():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", default="T2", type=str)
    parser.add_argument("--fd", default=256, type=int)
    parser.add_argument("--fg", default=256, type=int)
    parser.add_argument("--hyperedge_k", default=15, type=int)
    parser.add_argument("--validation", default=10, type=int)
    args = parser.parse_args()
    return args
class T1(object):
    def __init__(self):
        self.m = 263
        self.d = 480
        self.data_path = '../datasets/T1'
        self.epoch =4500
        self.fg = 256
        self.fd = 256
        self.k = 64
        self.btypes =['sim_enzyme', 'sim_path', 'sim_rr','sim_target']
        self.p=6059
        self.drop = 0.35
class T2(object):
    def __init__(self):
        self.m = 850
        self.d = 339
        self.data_path = '../datasets/T2'
        self.epoch =1400
        self.fg = 256
        self.fd = 256
        self.k = 64
        self.p = 5105
        self.drop=0.1
        self.btypes = ['Sim_drugsideEffect', 'drugsimChemicalnet', 'drugsimTherapeuticnet']
def get_edge(edge_index,opt):
    value = torch.ones(edge_index.shape[1])
    uv_edge_index = edge_index + torch.tensor([[0], [opt.m]])
    size = (opt.m+ opt.d,) * 2
    vu_edge_index=reversed(uv_edge_index)
    return (uv_edge_index,value, size),(vu_edge_index,value, size)
def build_hypergraph(sim, num_neighbor):
    if num_neighbor > sim.shape[0] or num_neighbor < 0:
        num_neighbor = sim.shape[0]
    neighbor = np.argpartition(-sim, kth=num_neighbor, axis=1)[:, :num_neighbor]
    row_index = np.arange(neighbor.shape[0]).repeat(neighbor.shape[1])
    col_index = neighbor.reshape(-1)
    zero=np.zeros((sim.shape[0],sim.shape[1]))
    zero[row_index, col_index]=sim[row_index, col_index]
    return zero
def build_muti_hypergraph(sim, num_neighbor):
    if num_neighbor > sim.shape[0] or num_neighbor < 0:
        num_neighbor = sim.shape[0]
    neighbor = np.argpartition(-sim, kth=num_neighbor, axis=1)[:, :num_neighbor]
    row_index = np.arange(neighbor.shape[0]).repeat(neighbor.shape[1])
    col_index = neighbor.reshape(-1)
    zero=np.zeros((sim.shape[0],sim.shape[1]))
    zero[row_index, col_index]=sim[row_index, col_index]
    return zero
def bce_loss_fn(predict, label, pos_weight):
    predict = predict.reshape(-1)
    label = label.reshape(-1)
    weight = pos_weight * label + 1 - label
    loss = F.binary_cross_entropy(input=predict, target=label, weight=weight)
    return loss
def loadGR1(mm):

    dig=np.ones(mm.shape[0])
    I=np.diag(dig)
    H=mm+I
    G = hgut._generate_G_from_H(H)
    return G
def loadGD1(dd):
    dig = np.ones(dd.shape[0])
    I = np.diag(dig)
    H = dd+I
    G = hgut._generate_G_from_H(H)
    return G
def to_numpy(x):
    return x.cpu().data.numpy()
class Myloss(nn.Module):
    def __init__(self):
        super(Myloss, self).__init__()
    def forward(self, target, input,test):
        loss1=bce_loss_fn(predict=input, label=target, pos_weight=(input.shape[0]*input.shape[1] - test['train_pos_edge'].shape[1]) / test['train_pos_edge'].shape[1])
        return loss1
def to_numpy(x):
    return x.cpu().data.numpy()
def train(model, train_data, optimizer, opt, test,  test_sample,dd_matrix,mm_matrix,GR,GD,zero,inter,ur_edge_index, ur_edge_weight,vr_edge_index, vr_edge_weight,r_p_one,d_p_one,p_p,hygraphs):
    regression_crit = Myloss()
    for epoch in range(1, opt.epoch+1):
        model.train()
        optimizer.zero_grad()
        score= model(dd_matrix,mm_matrix,GR,GD,zero,ur_edge_index, ur_edge_weight,vr_edge_index, vr_edge_weight,r_p_one,d_p_one ,p_p,hygraphs)
        loss = regression_crit(torch.FloatTensor(inter).cuda(), score,test)
        loss.backward()
        optimizer.step()
    model.eval()
    with torch.no_grad():
        target=train_data.cuda()
        preidct = model(dd_matrix, mm_matrix, GR, GD, zero, ur_edge_index, ur_edge_weight, vr_edge_index,
                        vr_edge_weight, r_p_one, d_p_one, p_p, hygraphs)
        test_sample = test_sample.T
        test_sample = test_sample.tolist()
        a = to_numpy(preidct[test_sample])
        b = to_numpy(target[test_sample])
    metric = metric_fn.evaluate(predict=a, label=b)
    a = np.array(list(metric.values()))
    print(a)
    return a
def concat(rr,dd):
    zero=np.zeros((rr.shape[0],dd.shape[0]))
    z1=np.hstack((rr,zero))
    z2=np.hstack((zero.T,dd))
    z=np.vstack((z1,z2))
    return z
def main():
    args = parse()
    if args.dataset=="T1":
        opt =T1()
    else:
        opt= T2()
    final11=0
    rr= np.loadtxt(opt.data_path + '/drug_sim.csv',delimiter=',')
    dd=np.loadtxt(opt.data_path + '/dis_sim.csv',delimiter=',')
    for i in range(args.validation):
        print('the %d cvtest',i)
        print('-'*50)
        model = Model(opt).to(device)
        optimizer = optim.Adam(model.parameters(), lr=0.002)
        data = scio.loadmat(os.path.join(opt.data_path, f"split_{i}.mat"))
        train_mask = data["train_pos_edge"].T
        test_sample=data["test"].T
        dr = np.zeros((opt.m,opt.d))
        for i in range(train_mask .shape[0]):
            dr[train_mask [i][0], train_mask [i][1]] = 1
        inter = dr
        rr = build_hypergraph(rr,args.hyperedge_k)
        dd= build_hypergraph(dd,args.hyperedge_k)
        hygraphs = dict()
        hygraphs['base'] =torch.FloatTensor(loadGR1(rr)).cuda()
        for b in opt.btypes:
            r_r=np.loadtxt(opt.data_path + '/' + b + '.txt', dtype=float)
            r_r=build_muti_hypergraph(r_r,args.hyperedge_k)
            data_type = loadGR1(r_r)
            hygraphs[str(b)] = torch.FloatTensor(data_type).cuda()
        index = torch.from_numpy(data["train_pos_edge"])
        uv_edge,vu_edge =get_edge(index,opt)
        ur_edge_index, ur_edge_weight = uv_edge[:2]
        ur_edge_index=ur_edge_index.to(device)
        ur_edge_weight =ur_edge_weight.to(device)
        vr_edge_index, vr_edge_weight = vu_edge[:2]
        vr_edge_index=vr_edge_index.to(device)
        vr_edge_weight =vr_edge_weight.to(device)
        zero = torch.FloatTensor(concat(rr, dd)).cuda()
        GR = loadGR1(rr)
        GD = loadGD1(dd)
        print(GR.shape)
        d_p_one=torch.load(opt.data_path +'/d_p_one.pt')
        r_p_one = torch.load(opt.data_path +'/r_p_one.pt')
        p_p=torch.load(opt.data_path +'/p_p_index.pt')
        label_target = np.loadtxt(opt.data_path + '/drug_dis.csv', delimiter=',')
        train_data = torch.FloatTensor(label_target)
        final=train(model, train_data, optimizer, opt, data, test_sample,dd,rr,GR,GD,zero,inter,ur_edge_index, ur_edge_weight,vr_edge_index, vr_edge_weight,r_p_one,d_p_one,p_p,hygraphs)
        final11=final11+final
    print('mean_result')
    print(final11 / args.validation)



if __name__ == "__main__":
    main()